<?=$page['title']?>
<?=$page['content']?>